$('.btn-menu').on('click touchstart', function () {
    $('html').toggleClass('btn-menu-active');
  });