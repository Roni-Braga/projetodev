<?php
include_once 'conexao.php';

$nome = $_POST['nome'];
$email = $_POST['email'];
$mensagem = $_POST['mensagem'];

$sql = "INSERT INTO mensagem (nome,email,mensagem) VALUES('$nome','$email','$mensagem')";


if(mysqli_query($conexao,$sql)){
  
    
echo"<script>alert('mensagem enviada')</script>";
echo"<script>document.location.href='contato.php'</script>";
}

else{
    echo"<script>alert('Mensagem não cadastrada')</script>"; 
    
}








?>