<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <title>CONTATO</title>
</head>
<style type=text/css>
  
   ul li{
        list-style:none;
        float:left;
        margin-top:5px;
       
        
    }
    ul li a{
        text-decoration:none;
        padding:10px;
       margin-left: 60px;
       color: whitesmoke;
      
   
}



h2{
    font-size:20px;
    text-align:center;
    margin-top:30px;
}
.conteudo{
    width: 1024px;
    height: 200px;
    background: cadetblue;
    color:white;
    text-align: center;
    float:left;
    font-family:arial;
    
}
footer{
    background: cadetblue;
    text-align:center;
    height:65px;
    color:white;
    width: 1024px;
    border-top: solid 1px;
    float:left;
    font-family:arial;
    
}
.head{
    background: cadetblue;
  margin-top:10px;
    width: 1024px;
    height:40px;
    margin-top:-20px;
  

}
body{
    background: #FFFAFA;
    overflow-x:hidden;
    
   

}
.contato{
    height: 600px;
    background: #FFFAFA;
}
.tab{
    margin-left: 300px;
    margin-top: 100px;
    
   
}
.tab input{
    margin:10px;
    width: 300px;
    color: white;
    
}
.tab input:hover{
    background: #4682B4;
}
.tab textarea{
    margin-left: 15px;
    width: 400px;
    height: 150px;
    color: white;
}
.tab textarea:hover{
    background:#4682B4;
}
p{
    margin: 10px;
}
.ban{
    width:100%;
}


@media only screen and (min-width: 500px) and (max-width:800px){
    .head{
        
        font-size: 13px;
       
        margin-left: -50px;
    }
    
   
    .conteudo{
        width: 800px;
    }
    footer{
        width: 800px;
    }
    .contato{
        width: 800px;
    }
    .tab{
        margin-left:100px;
    }
    .ban{
        width:800px;
    }
    

}

@media only screen and (max-width: 500px){
    .ban{
        width: 500px;
    }
    .conteudo{
        display:none;
    }
    footer{
        width:500px;
        height:78px;
    }
    p{
        padding: 5px;
    }
    h2{
        font-size: 20px;
       
    }
    .contato{
        width: 500px;
    }
    .tab{
        margin-left: 30px;
    }
    .tab input{
    margin:10px;
    width: 200px;
    color: black;
    
}
.tab input:hover{
    background: #4682B4;
    color: white;
}
.tab textarea{
    margin-left: 15px;
    width: 300px;
    height: 150px;
    color:black;
    
}
.tab textarea:hover{
    background:#4682B4;
    color: white;
}
p{
    margin: 8px;
}
.head  {
        font-size:12px;
        
        
    }
    .head li a{
        margin-left:15px;
    }
   
}


        </style>
<body>
<section>
      <div class="head">  <ul>
            <li><a href="index.php">PAGINA INICIAL</a></li>
            <li><a href="front.php"> FRONT-END</a></li>
            <li><a href="back.php">BACK-END</a></li>
            <li><a href="full.php">FULL-STACK</a></li>
            <li><a href="contato.php">CONTATO</a></li>
           
           
</ul>
</div>
</section>
<section>
  <img src="img/banner.png" class="ban">



</section>

<section>
<div class="contato">
<form action="processa.php" method="POST"> 
   <h2>Ficou com alguma Duvida?</h2>
   <p>Preencha o Formulário abaixo e tire todas sua Dúvidas. Aceitamos também Sugestões e Reclamações.
       Nos ajude á melhorar o conteúdo da página. Nosso objetivo é proporciona a você o melhor Conteúdo.
   </p>
  <table class="tab">
      <tr>    
      <td>
    <label>Nome</label>
    </td>
     <td>
<input type="text" name="nome"></td>
     </tr>
     <tr>
    <td><label>E-mail</label></td>
    <td><input type="email" name="email"></td></tr>
    <tr><td><label>Mensagem</label></td>
    <td><textarea name="mensagem"></textarea></td></tr>
    <tr><td><button class="btn btn-primary">Enviar</button>
</form>
</table>
</div>
</section>
<div class="conteudo" >
   <div class="row" >
<div class="col" style="border-right:solid 1px;" >
        <h2>Inteligência Artificial</h2>

       <br>
        <ul> 
            <li><a href="sobre.php">Conceito</a></li>
            <li><a href="historia.php">Onde Surgiu</a></li>
            <li><a href="dias.php">Atualidades</a></li>
        </ul>
    </div>
    
    <div class="col" style="border-right:solid 1px;">
        <h2>Dev´ops</h2>
        <br>
        <ul>
            <li><a href="sobre.php">Conceito</a></li>
            <li><a href="historia.php">Onde Surgiu</a></li>
            <li><a href="dias.php">Atualidades</a></li>
        </ul>
    </div>
    <div class="col" >
        <h2>Cyber Security</h2>
        <br>
        <ul>
            <li><a href="sobre.php">Conceito</a></li>
            <li><a href="historia.php">Onde Surgiu</a></li>
            <li><a href="dias.php">Atualidades</a></li>
        </ul>
    </div>

</div>



</div>



<footer><p>Todos os Direitos Reservado á Ronielson</p>
 <p style="float:right; margin-right:50px;margin-top:-16px;">   
<a href="https://www.github.com/Roni-Braga" target="_blank"><img src="img/git.png" style="width:30px;"></a>
<a href="https://www.instagram.com" target="_blank"><img src="img/insta.png" width="30px"></a>
<a href="https://www.twitter.com" target="_blank"><img src="img/twitter.png" width="30px"></a>
<a href="https://www.linkedin.com/in/ronielson-sousa" target="_blank"><img src="img/in.png" width="30px"></p></a>
</footer>








     





    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" 
    integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" 
    crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" 
integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" 
crossorigin="anonymous"></script>
</body>
</html>