<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <title>BACK-END</title>
</head>
<style type=text/css>
 ul li{
        list-style:none;
        float:left;
        margin-top:5px;
       
        
    }
    ul li a{
        text-decoration:none;
        padding:10px;
       margin-left: 60px;
       color: whitesmoke;
      
   
}



h2{
    font-size:20px;
    text-align:center;
    margin-top:30px;
}
.conteudo{
    width: 1024px;
    height: 200px;
    background: cadetblue;
    color:white;
    text-align: center;
    float:left;
    font-family:arial;
    
}
body{
    overflow-x: hidden;
}
footer{
    background: cadetblue;
    text-align:center;
    height:65px;
    color:white;
    width: 1024px;
    border-top: solid 1px;
    float:left;
    font-family:arial;
    
}
.head{
    background: cadetblue;
  margin-top:10px;
    width: 1024px;
    height:40px;
    margin-top:-20px;
  

}
.boot{
    margin-top:50px;
    margin-left: 100px;
    margin-right: 80px;
    font-family:arial;
}
.found{
    margin-left: 100px;
    margin-right: 80px;
    font-family:arial;
}
.mat{
    margin-left: 100px;
    margin-right: 80px;
    font-family:arial;
}
@media only screen and (min-width: 500px) and (max-width:800px){
    .head{
        
        font-size: 13px;
       
        margin-left: -50px;
    }
    .ban{
        width: 800px;
    }
    .conteudo{
        width: 800px;
    }
    footer{
        width: 800px;
    }
}

@media only screen and (max-width: 500px){
    .ban{
        width: 500px;
    }
    .conteudo{
        display:none;
    }
    footer{
        width:500px;
    }
    p{
        padding: 5px;
    }
    h2{
        font-size: 20px;
       
    }
    .head  {
        font-size:12px;
        
        
    }
    .head li a{
        margin-left:15px;
    }
   
}




</style>
<body>
<section>
      <div class="head">  <ul>
            <li><a href="index.php">PAGINA INICIAL</a></li>
            <li><a href="front.php"> FRONT-END</a></li>
            <li><a href="back.php">BACK-END</a></li>
            <li><a href="full.php">FULL-STACK</a></li>
            <li><a href="contato.php">CONTATO</a></li>
           
           
</ul>
</div>
</section>
<section>
  <img src="img/banner.png" class="ban">

</section>
<h2>FRAMEWORK´S MAIS UTILIZADOS NO MUNDO BACK-END</h2>
<div class="boot">
    <h3>1.Spring Boot</h3>
    <img src="img/java.png" style="width:130px; float:left; margin:10px;">
    <br> <br>
    <p>Spring Framework é uma estrutura de aplicativo de código aberto 
        e o recipiente de inversão de controle da plataforma Java. 
        Os aplicativos Java podem utilizar os principais recursos desta estrutura.
         Os usuários também podem usar muitas extensões para criar aplicativos da web baseados na plataforma Java EE.
    </p>
  
   
    <p>
          <br>
   <p style="text-align:center;"> <b>Vantagens</b></p>
   <li> Suporte integrado para Undertow, Jetty e Tomcat</li>
    <li>A configuração padrão não é necessária</li>
   <li> O reinício automático do servidor é para atualizações de código e configuração é facilitado por DevTools</li>
   <li> O gerenciamento de dependências é mais fácil</li>
    <li>Propriedades específicas do perfil são facilmente gerenciadas</li>
    <li>As propriedades do aplicativo são facilmente personalizadas</li>
    <li>SpringBoot Starters são convenientes para desenvolvedores</li>
</p>
<p><b>Recursos</b>
<b>Inicialização – </b>SpringBoot ajuda os desenvolvedores a realizar uma inicialização lenta.
     Ativar esse recurso ajuda os desenvolvedores a criar beans com base nos requisitos, 
     em vez de durante a inicialização de um aplicativo. Portanto, a inicialização lenta pode reduzir o tempo necessário para o aplicativo iniciar.
</p>
<p>
<b>Personalização de banner – </b>os banners de inicialização podem ser modificados pelos usuários adicionando um arquivo banner.
txt ao seu classpath. Banners também podem ser modificados apontando a propriedade spring.banner.location para o local do arquivo relevante.
 Os usuários podem definir um spring.banner.charset para arquivos usando codificação fora de UTF-8. Os usuários podem adicionar imagens banner.jpg, 
 banner.gif e banner.png junto com arquivos de texto a um classpath. Eles também podem definir spring.banner.image.location.
</p>
<b>Construtor de APIs –</b> os desenvolvedores podem usar SpringApplicationBuilder se precisarem construir uma hierarquia ApplicationContext ou utilizar sua API de construtor fluente.
</p>
</div>
<div class="found">
<h3>2.django</h3>
<img src="img/py.jpg" style="width:130px; float:left; margin:10px;">
<p>
Django é um framework backend de código aberto baseado na linguagem de programação Python. 
Ele segue o padrão model view controller (MVC). Django é adequado para o desenvolvimento de sites sofisticados e ricos em recursos baseados em banco de dados.
</p>
<p>
<p style="text-align:center;"><b>Vantagens</b></p><br>
<b>Velocidade –</b> Django é fácil de usar e uma estrutura de baixa curva de aprendizado criada para ajudar os desenvolvedores a acelerar todo o processo de desenvolvimento do início ao fim.
</p>
<p>
<b>Rico em recursos – </b>o Django fornece uma ampla variedade de recursos para ajudar os usuários a cuidar de alguns requisitos comuns de desenvolvimento da web. Ajuda em tarefas como autenticação de usuário, 
sitemaps, administração de conteúdo e muito mais.
</p>
<p>
<b>Segurança ideal – </b>Django é uma estrutura segura que ajuda seus usuários a prevenir vários problemas de segurança, incluindo cross-site scripting, clickjacking, injeção de SQL e falsificação de solicitação.
 Ele fornece um sistema de autenticação de usuário para permitir que os usuários armazenem e gerenciem senhas e contas com segurança.  
</p>
</div>
<div class="mat">
<h3>3.c#</h3>
    <img src="img/c.jpg" style="width:130px; float:left; margin:10px;">
    
    <p>
    ASP.NET Core é uma estrutura de código aberto e gratuita que segue os passos do ASP.NET, 
    um back-end amplamente usado criado em parceria com a .NET Foundation. ASP.NET Core é 
    uma estrutura modular que pode ser executada em todo o .NET Framework no Windows e .NET Core.
    <p style="text-align:center;"><b>Vantagens</b></p>
    </p>
    <p>
    <b>Suporte de plataforma cruzada – </b>
    o desenvolvimento de aplicativos da Web requer que os desenvolvedores garantam que um aplicativo forneça suporte para todas as plataformas. 
    O novo ASP.NET Core é uma estrutura de back-end de aplicativo da Web de plataforma cruzada que oferece suporte para várias plataformas.
     ASP.NET Core é uma solução de plataforma cruzada para desenvolver aplicativos da Web para as plataformas Windows, Mac e Linux. 
     O back-end usa o mesmo código C # em todas as plataformas.
</p>

<p>
<b>Codificação mínima – </b>o ASP.NET Core usa tecnologia que requer menos codificação. Isso significa que os desenvolvedores acham o uso do back-end bastante conveniente, 
pois precisam construir menos instruções. Menos codificação se traduz em menos tempo necessário para criar um aplicativo. Como resultado,
 os desenvolvedores exigem menos tempo para criar um aplicativo e o processo também é econômico.
</p>
<p>
<b>A manutenção é fácil –</b>
 menos código também significa menos manutenção. O ASP.NET Core pode ser mantido automaticamente em casos com uma pequena quantidade de código. 
 Desenvolvedores experientes podem facilmente obter uma noção sobre como reduzir o esforço de manutenção para um back-end ASP.NET Core.
  Eles podem otimizar o código ASP.NET com apenas algumas in

</p>

</div>
<div class="mat">
<h3>3.Laravel</h3>
    <img src="img/php.png" style="width:130px; float:left; margin:10px;">
    <p>
    é uma estrutura da web PHP de código aberto para o desenvolvimento de aplicativos da web baseados em Symfony que seguem a arquitetura model – view – controller (MVC). 
    Ele oferece um sistema de empacotamento modular equipado com um gerenciador de dependências dedicado. O Laravel também fornece a seus usuários várias maneiras de acessar bancos de dados relacionais,
     juntamente com manutenção de aplicativos e utilitários de implantação. O Laravel possui uma licença MIT e um código-fonte hospedado no GitHub.

    </p>
    
    <p style="text-align:center;"> <b>Vantagens</b></p><br>
    <b>Autenticação:</b> A implementação da autenticação é bastante simples com o Laravel, pois oferece fácil configuração. O Laravel facilita a organização de lógica de autorização simples e fácil controle de recursos de acesso.
</p>

<p>
<b>API simples:</b> o Laravel oferece uma API simples que funciona de maneira fluida com a biblioteca SwiftMailer. Laravel oferece drivers para Mandrill, SMTP, Mailgun, Amazon SES e SparkPost. Ele também possui drivers para e-mail PHP e envia e-mails.
 O Laravel permite o envio rápido de e-mails de aplicativos através de um serviço local ou baseado em nuvem. Ele também fornece suporte de envio de notificação em vários canais de entrega.
</p>

<p>
<b>Cache:</b> o Laravel oferece suporte para Redis, Memcached e outros backends de cache amplamente usados. Ele usa o driver de cache de arquivo, que executa o armazenamento de objetos em cache em um sistema de arquivos.
 Aplicativos maiores usam um cache na memória como APC ou Memcached. O Laravel também permite que os usuários façam várias configurações de cache.
</p>

</div>
</section>
<br><br>
<div class="conteudo" >
   <div class="row" >
<div class="col" style="border-right:solid 1px;" >
        <h2>Inteligência Artificial</h2>

       <br>
        <ul> 
            <li><a href="sobre.php">Conceito</a></li>
            <li><a href="historia.php">Onde Surgiu</a></li>
            <li><a href="dias.php">Atualidades</a></li>
        </ul>
    </div>
    
    <div class="col" style="border-right:solid 1px;">
        <h2>Dev´ops</h2>
        <br>
        <ul>
            <li><a href="sobre.php">Conceito</a></li>
            <li><a href="historia.php">Onde Surgiu</a></li>
            <li><a href="dias.php">Atualidades</a></li>
        </ul>
    </div>
    <div class="col" >
        <h2>Cyber Security</h2>
        <br>
        <ul>
            <li><a href="sobre.php">Conceito</a></li>
            <li><a href="historia.php">Onde Surgiu</a></li>
            <li><a href="dias.php">Atualidades</a></li>
        </ul>
    </div>

</div>



</div>



<footer><p style="">Todos os Direitos Reservado á Ronielson</p>
 <p style="float:right; margin-right:50px;margin-top:-24px;">   
 <a href="https://www.github.com/Roni-Braga" target="_blank"><img src="img/git.png" style="width:30px;"></a>
<a href="https://www.instagram.com" target="_blank"><img src="img/insta.png" width="30px"></a>
<a href="https://www.twitter.com" target="_blank"><img src="img/twitter.png" width="30px"></a>
<a href="https://www.linkedin.com/in/ronielson-sousa" target="_blank"><img src="img/in.png" width="30px"></p></a>
</footer>








     





    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" 
    integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" 
    crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" 
integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" 
crossorigin="anonymous"></script>
</body>
</html>