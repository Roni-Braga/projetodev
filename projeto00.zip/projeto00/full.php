<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <title>BACK-END</title>
</head>
<style type=text/css>
 ul li{
        list-style:none;
        float:left;
        margin-top:5px;
       
        
    }
    ul li a{
        text-decoration:none;
        padding:10px;
       margin-left: 60px;
       color: whitesmoke;
      
   
}



h2{
    font-size:20px;
    text-align:center;
    margin-top:30px;
}
.conteudo{
    width: 1024px;
    height: 200px;
    background: cadetblue;
    color:white;
    text-align: center;
    float:left;
    font-family:arial;
    
}
body{
    overflow-x: hidden;
}
footer{
    background: cadetblue;
    text-align:center;
    height:65px;
    color:white;
    width: 1024px;
    border-top: solid 1px;
    float:left;
    font-family:arial;
    
}
.head{
    background: cadetblue;
  margin-top:10px;
    width: 1024px;
    height:40px;
    margin-top:-20px;
  

}
.texto{
  margin-left: 100px;
    margin-right: 80px;
    font-family:arial;
}
.frame{
        width: 200px;
        padding: 10px;
    }

@media only screen and (min-width: 500px) and (max-width:800px){
    .head{
        
        font-size: 13px;
       
        margin-left: -50px;
    }
    .ban{
        width: 800px;
    }
    .conteudo{
        width: 800px;
    }
    footer{
        width: 800px;
    }
    .frame{
        width: 150px;
        padding: 10px;
    }
}

@media only screen and (max-width: 500px){
    .ban{
        width: 500px;
    }
    .conteudo{
        display:none;
    }
    footer{
        width:500px;
    }
    p{
        padding: 5px;
    }
    h2{
        font-size: 20px;
       
    }
    .frame{
        width: 80px;
        padding: 10px;
    }
    .head  {
        font-size:12px;
        
        
    }
    .head li a{
        margin-left:15px;
    }
   
   
}

 </style>
<body>
<section>
      <div class="head">  <ul>
            <li><a href="index.php">PAGINA INICIAL</a></li>
            <li><a href="front.php"> FRONT-END</a></li>
            <li><a href="back.php">BACK-END</a></li>
            <li><a href="full.php">FULL-STACK</a></li>
            <li><a href="contato.php">CONTATO</a></li>
           
           
</ul>
</div>
</section>
<section>
  <img src="img/banner.png" class="ban">

</section>
<section>
  <div class="texto">
<h2><b>DESENVOLVEDOR FULL STACK</b> </h2>
<p>A tradução literal de Full Stack é “pilha toda” e, com isso, temos uma ideia geral acerca de porquê esse nome se refere a pessoa que trabalha com todas as tecnologias que envolvem o desenvolvimento web.</p>

<p>A Stack de desenvolvimento é o conjunto geral de tecnologias de uma aplicação. Por exemplo, para web, é comum que o front-end seja desenvolvido com HTML, CSS e Javascript, enquanto o back-end pode ser criado com PHP e o banco de dados MySQL.</p>

<p>Por isso, espera-se que a pessoa programadora Full Stack seja capacitada o suficiente para lidar, ao mesmo tempo, com o front-end e o back-end de uma aplicação, mesmo que os dois pontos utilizem tecnologias e linguagens diferentes.</p>
<p>Algumas empresas ainda denominam Full Stack profissionais que não apenas tratam desses dois lados do sistema, mas que também lidam com o banco de dados e modele tabelas e configuração dos servidores nos quais a aplicação roda.</p>

<p>Também são chamamos de Full Stack quem conseguem trabalhar com back-end e aplicações mobile, que podem ser consideradas como front-end. Essas pessoas vêm sendo cada vez mais requisitado no mercado.</p>

<b>O que faz um profissional Full Stack?</b>
<p>O Full Stack acaba acumulando várias funções dentro de uma empresa, porém, não há nada com que se preocupar. Com o tempo, ele aprende a gerenciar de forma simples suas atividades, uma vez que tudo pode ser feito seguindo uma etapa lógica. 
  A seguir, você confere as principais responsabilidades desse profissional.</p>

<b>Levantamento de requisitos</b>
<p>A figura do analista de negócios não existe, sendo que a responsabilidade de coletar e analisar os requisitos, buscando modelar as funcionalidades, é totalmente do Full Stack.</p>

<p>Quando se trabalha com metodologias ágeis, como o SCRUM, isso é feito diversas vezes ao longo do desenvolvimento. Como o Full Stack tem uma visão macro, já que trabalha em todo o projeto, o levantamento de requisito pode ser bem mais eficiente.</p>

<b>Modelagem de banco de dados</b>
<p>Criar e modelar um banco de dados é fundamental em qualquer aplicação. Além de salvar todos os registros do sistema, uma modelagem ruim pode trazer problemas de desempenho no futuro, além de prejudicar a lógica da programação.</p>

<p>Esse é um dos pontos sensíveis para o Full Stack. Muitas empresas preferem contratar especialistas para realizar a modelagem, deixando que o pessoal da programação apenas lide com os dados posteriormente.</p>

<b>Programação back-end</b>
<p>O desenvolvimento, na maioria das vezes, inicia-se pelo back-end, utilizando uma das mais variadas tecnologias que existem para esse fim, como PHP, Java, Python, entre outras.</p>

<p>Aquele que programa Full Stack pode conhecer mais de uma dessas linguagens, existindo ainda a possibilidade de entendimento acerca do uso de frameworks que agilizam o trabalho de desenvolvimento.</p>

<b>Programação front-end</b>
<p>O front-end é construído com base nas tecnologias web que são HTML, CSS e Javascript. O Full Stack deve sempre buscar melhorar nesse ponto, uma vez que essa stack é uma das que mais evolui, sempre trazendo novidades.</p>

<b>Programação mobile</b>
<p>Com a inserção de possibilidades de uso de tecnologias como o Javascript para o desenvolvimento de aplicativos mobile, o Full Stack também pode agregar aos seus conhecimentos a criação de apps. O React Native é um dos frameworks mais famosos para isso.</p>

<b>Configuração de servidor</b>
<p>Por fim, temos a configuração de servidor para que a aplicação funcione, sendo que muitas empresas exigem esse conhecimento básico. Lembrando que essa também é uma atividade sensível, pois lida com segurança de dados.</p>

<p>Caso o profissional seja contratado por uma empresa que esteja iniciando o desenvolvimento de uma aplicação, pode ser que ele atue em todas essas funções, dividindo-se conforme a demanda. No entanto, na maioria das vezes, já temos o sistema no ar.</p>

<p>Nesse caso, a responsabilidade do Full Stack pode girar em torno de desenvolver novas funcionalidades ou apenas de garantir a manutenção das funções existentes no sistema. Quanto ele dispensará de tempo entre o back e o front-end dependerá exclusivamente da demanda geral</p>
<p><b>Técnologias usadas pelo Full Stack:</b><br>
<img src="img/node.png" class="frame">
<img src="img/angular.png" class="frame" >
<img src="img/react.png" class="frame"></p>
</div>

<div class="conteudo" >
   <div class="row" >
<div class="col" style="border-right:solid 1px;" >
        <h2>Inteligência Artificial</h2>

       <br>
        <ul> 
            <li><a href="sobre.php">Conceito</a></li>
            <li><a href="historia.php">Onde Surgiu</a></li>
            <li><a href="dias.php">Atualidades</a></li>
        </ul>
    </div>
    
    <div class="col" style="border-right:solid 1px;">
        <h2>Dev´ops</h2>
        <br>
        <ul>
            <li><a href="sobre.php">Conceito</a></li>
            <li><a href="historia.php">Onde Surgiu</a></li>
            <li><a href="dias.php">Atualidades</a></li>
        </ul>
    </div>
    <div class="col" >
        <h2>Cyber Security</h2>
        <br>
        <ul>
            <li><a href="sobre.php">Conceito</a></li>
            <li><a href="historia.php">Onde Surgiu</a></li>
            <li><a href="dias.php">Atualidades</a></li>
        </ul>
    </div>

</div>



</div>



<footer><p>Todos os Direitos Reservado á Ronielson</p>
 <p style="float:right; margin-right:50px;margin-top:-24px;">   
 <a href="https://www.github.com/Roni-Braga" target="_blank"><img src="img/git.png" style="width:30px;"></a>
<a href="https://www.instagram.com" target="_blank"><img src="img/insta.png" width="30px"></a>
<a href="https://www.twitter.com" target="_blank"><img src="img/twitter.png" width="30px"></a>
<a href="https://www.linkedin.com/in/ronielson-sousa" target="_blank"><img src="img/in.png" width="30px"></p></a>
</footer>








     





    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" 
    integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" 
    crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" 
integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" 
crossorigin="anonymous"></script>
</body>
</html>