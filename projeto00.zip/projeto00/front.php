<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1, maximum-scale=1, user-scalable=no" />
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <title>FRONT-END</title>
</head>
<style type=text/css>
  
   ul li{
        list-style:none;
        float:left;
        margin-top:5px;
       
        
    }
    ul li a{
        text-decoration:none;
        padding:10px;
       margin-left: 60px;
       color: whitesmoke;
      
   
}
body{
    overflow-x: hidden;
}


h2{
    font-size:20px;
    text-align:center;
    margin-top:30px;
}
.conteudo{
    width: 1024px;
    height: 200px;
    background: cadetblue;
    color:white;
    text-align: center;
    float:left;
    font-family:arial;
    
}
footer{
    background: cadetblue;
    text-align:center;
    height:65px;
    color:white;
    width: 1024px;
    border-top: solid 1px;
    float:left;
    font-family:arial;
    
}
.head{
    background: cadetblue;
  margin-top:10px;
    width: 1024px;
    height:40px;
    margin-top:-20px;
   
  

}
.boot{
    margin-top:50px;
    margin-left: 100px;
    margin-right: 80px;
    font-family:arial;
}
.found{
    margin-left: 100px;
    margin-right: 80px;
    font-family:arial;
}
.mat{
    margin-left: 100px;
    margin-right: 80px;
    font-family:arial;
}

@media only screen and (min-width: 500px) and (max-width:800px){
    .head{
        
        font-size: 13px;
       
        margin-left: -50px;
    }
    .ban{
        width: 800px;
    }
    .conteudo{
        width: 800px;
    }
    footer{
        width: 800px;
    }
}

@media only screen and (max-width: 500px){
    
  
   
    .ban{
        width: 500px;
    }
    
    .conteudo{
        display:none;
    }
    footer{
        width:500px;
    }
    p{
        padding: 5px;
    }
    h2{
        font-size: 20px;
       
    }
    .head  {
        font-size:12px;
        
        
    }
    .head li a{
        margin-left:15px;
    }
   
}
        </style>
<body>

<section>
      <div class="head">  <ul>
            <li><a href="index.php">PAGINA INICIAL</a></li>
            <li><a href="front.php"> FRONT-END</a></li>
            <li><a href="back.php">BACK-END</a></li>
            <li><a href="full.php">FULL-STACK</a></li>
            <li><a href="contato.php">CONTATO</a></li>
           
         
  </nav>     
</ul>
</div>
</section>
<section>
  <img src="img/banner.png" class="ban">

</section>
<section>

<h2>FRAMEWORK´S MAIS UTILIZADOS NO MUNDO FRONT-END</h2>
<div class="boot">
    <h3>1.Bootstrap</h3>
    <img src="img/boot.jpg" style="width:130px; float:left; margin:10px;">
    <p>framework mais conhecido e famoso do mundo front-end.
     Criado em agosto de 2011 por dois engenheiros do Twitter,
      a ferramenta logo se tornou uma das mais famosas na hora de criar interfaces web.
    </p>
    <p>
    Hoje estima-se que cerca de 7 milhões de sites utilizem o Bootstrap como framework front-end. 
    Entre suas vantagens, podemos citar a documentação farta e a comunidade muito ativa, 
    a infinidade de componentes que podem ser facilmente chamados em suas aplicações, 
    além da boa base de padrões estéticos, que permitem criar páginas belas e funcionais.
</p>
<p>
Pode parecer muito elogio, mas o Bootstrap realmente merece atenção, 
porque as páginas criadas com ele ficam atrativas e eficientes.
 Você pode ver mais sobre Bootstrap nesse artigo que fizemos especificamente sobre o framework. 
 Afinal de contas, ele merece!
</p>
</div>
<div class="found">
<h3>2.Foundation</h3>
<img src="img/found.jpg" style="width:130px; float:left; margin:10px;">
<p>
Se você já ouviu falar em SASS, então provavelmente deve conhecer o framework Foundation, 
lançado em 2011. Isso porque a base dele é no pré-processador SASS,
 além de ser um dos frameworks front-end mais utilizados no mundo.
</p>
<p>
A vantagem de ser construído em SASS é que ele permite uma construção de aplicações mais rápida, 
chamando diversas funções de estilo prontas. Além disso, ele também possui integração com o JavaScript, 
o que permite diferentes efeitos em sua utilização.
</p>
<p>
Por seguir os princípios de mobile first e melhoria progressiva, o Foundation tem a vantagem de manter um código enxuto e conciso,
 além de estar adaptado para os diferentes tipos de tela. Estes são alguns dos elementos que o fazem ser tão conhecido e utilizado. 
 Conheça o mascote do Foundation e dê uma olhada na página oficial da ferramenta.
</p>
</div>
<div class="mat">
<h3>3.Materialize</h3>
    <img src="img/mat.png" style="width:130px; float:left; margin:10px;">
    <p>
    Assim como o Material-UI, o Materialize é um framework front-end que utiliza o Material Design como base de inspiração para cores, 
    ícones e formatos. Assim como os demais frameworks, ele pode ser baixado para um projeto ou ser acessado via CDN através de um simples import.

    </p>
    <p>
    Uma de suas vantagens é que ele tira muito proveito do jQuery, fazendo com que seja uma ferramenta cheia de recursos visuais, como Captions, 
    Modais e Lightbox. Outra coisa interessante é o sistema de grids, parecido com o do Bootstrap…
</p>

<p>
Outro ponto positivo é que ele tem elementos exclusivos para aparelhos móveis, como aquele menu hambúrguer muito usado em aplicativos e sites para celular.
 Ele é considerado também mais leve e agradável que outros frameworks, o que o faz ser uma escolha muito comum e certeira.
</p>

</div>
</section>
<div class="conteudo" >
   <div class="row" >
<div class="col" style="border-right:solid 1px;" >
        <h2>Inteligência Artificial</h2>

       <br>
        <ul> 
            <li><a href="sobre.php">Conceito</a></li>
            <li><a href="historia.php">Onde Surgiu</a></li>
            <li><a href="dias.php">Atualidades</a></li>
        </ul>
    </div>
    
    <div class="col" style="border-right:solid 1px;">
        <h2>Dev´ops</h2>
        <br>
        <ul>
            <li><a href="sobre.php">Conceito</a></li>
            <li><a href="historia.php">Onde Surgiu</a></li>
            <li><a href="dias.php">Atualidades</a></li>
        </ul>
    </div>
    <div class="col" >
        <h2>Cyber Security</h2>
        <br>
        <ul>
            <li><a href="sobre.php">Conceito</a></li>
            <li><a href="historia.php">Onde Surgiu</a></li>
            <li><a href="dias.php">Atualidades</a></li>
        </ul>
    </div>

</div>



</div>



<footer><p style="">Todos os Direitos Reservado á Ronielson</p>
 <p style="float:right; margin-right:50px;margin-top:-24px;">   
 <a href="https://www.github.com/Roni-Braga" target="_blank"><img src="img/git.png" style="width:30px;"></a>
<a href="https://www.instagram.com" target="_blank"><img src="img/insta.png" width="30px"></a>
<a href="https://www.twitter.com" target="_blank"><img src="img/twitter.png" width="30px"></a>
<a href="https://www.linkedin.com/in/ronielson-sousa" target="_blank"><img src="img/in.png" width="30px"></p></a>
</footer>








     





    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" 
    integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" 
    crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" 
integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" 
crossorigin="anonymous"></script>
</body>
</html>