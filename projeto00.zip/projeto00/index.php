<html>
    <head></head>
    <meta charset ="utf-8">
    <title>INICIO</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="https://cpwebassets.codepen.io/assets/common/stopExecutionOnTimeout-1b93190375e9ccc259df3a57c1abc0e64599724ae30d7ea4c6877eb615f89387.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cpwebassets.codepen.io/assets/editor/iframe/iframeRefreshCSS-4793b73c6332f7f14a9b6bba5d5e62748e9d1bd0b5c52d7af6376f3d1c625d7e.js"></script>
<script scr="ativo.js"></script>
   <style type=text/css>
  
   ul li{
        list-style:none;
        float:left;
        margin-top:5px;
      
       
        
    }
    ul li a{
        text-decoration:none;
        padding:10px;
       margin-left: 60px;
       color: whitesmoke;
      
      
        
        
    }
.cont{
    width: 30%;   
    height:300px;
    border-radius: 180px;
margin-top: 10px;
margin-left: 30px;


}
footer{
    background: cadetblue;
    text-align:center;
    height:65px;
    color:white;
    width: 1024px;
    border-top: solid 1px;
    float:left;
    font-family:arial;
    
}
.head{
    background: cadetblue;
 
    width: 1024px;
    height:50px;
    margin-top:-20px;
} 
.conteudo{
    width: 1024px;
    height: 200px;
    background: cadetblue;
    color:white;
    text-align: center;
    float:left;
    font-family:arial;
    
}
body{
    overflow-x: hidden;
}
h2{
    font-size:20px;
}

.botao{
    background:#cccccc; 
    padding:15px; 
    position:relative; 
  margin-top:50px;
     left:120px;
      width:50%;
       float:left;
       margin-left:300px;
      top:-200px;
      font-family:arial;
     }
.botao:before{
     content:'';
      position: absolute;
       width:20px;
        height:20px; 
        left:-10px;
         top:35px; 
         background:#cccccc;
          -webkit-transform:rotate(45deg); 
          font-family:arial;
          }
.cont1{
    width: 30%;   
    height:300px;
    border-radius: 180px;
margin-top: 50px;
margin-left: 30px;


}
.program{
       margin-left: 100px;
       margin-top: 150px;
    }
    .program1{
        margin-top:-150px;
        margin-left: 100px;

    }
   .program3{
       margin-top:-150px;
       margin-left:100px;
   }
   .ban{
       margin-top:-10px;
   }
   
 
@media only screen  and (min-width: 500px) and (max-width: 800px){
    .head{
        
        font-size: 13px;
       
        margin-left: -50px;
    }
    .ban{
        width: 800px;
    }
    .conteudo{
        width: 800px;
    }
    footer{
        width: 800px;
    }
    .botao{
        width: 500px;
        margin-left:120px;
        height: 250px;
        font-size:14px;
    }
    .program{
        margin-left: -10px;
    }
    .program1{
        margin-left:-10px;
        margin-top:-100px;
        

    }
    .program3{
        margin-left: -10px;
        
    }
}


@media only screen and  (max-width:500px) {
    .head  {
        font-size:12px;
        
        
    }
    .head li a{
        margin-left:15px;
    }
   
   
    
    .ban{
        width:500px;
    }
    .botao{
        margin-top: 300px;
        margin-left:-70px;
        width: 400px;
        font-size: 12px;
    }
    .program{
       margin-left: 100px;
       width:200px;
    }
    .program1{
        margin-top:-150px;
        margin-left: 100px;
        width:200px;

    }
   .program3{
       margin-top:-150px;
       margin-left:100px;
       width:200px;
   }
   .conteudo{
      display:none;
      

   }
   h2{
       font-size:15px;

   }
   footer{
        width:500px;
    }
   
}
p{
    margin-right:70px;
}



}


</style>


  
<body>
    
        <section>
      <div class="head">  <ul>
            <li><a href="index.php">PAGINA INICIAL</a></li>
            <li><a href="front.php"> FRONT-END</a></li>
            <li><a href="back.php">BACK-END</a></li>
            <li><a href="full.php">FULL-STACK</a></li>
            <li><a href="contato.php">CONTATO</a></li>
           
           
</ul>

</div>

 

</section>
<section>
  <img src="img/banner.png"class="ban">

</section>

    <div class="cont">
    <img src="img/html.png" class="program" ></div>
  <div class="botao">
 <p><b> Desenvolvimento web:</b> Os desenvolvedores usam códigos HTML para projetar como um navegador 
 vai exibir os elementos das páginas, como textos, hiperlinks e arquivos de mídia.</p>
<p><b> Navegação na internet:</b> Os usuários podem navegar facilmente e inserir links entre páginas e sites relacionados, já que o HTML é amplamente usado para incorporar hiperlinks.</p>
<p><b> Documentação:</b> O HTML torna possível a organização e a formatação de documentos, de maneira similar ao Microsoft Word.</p>
  </div>

    <div class="cont1">
    <img src="img/css.png" class="program1">

    
</div><div class="botao"><p><b>Historia:</b> CSS foi desenvolvido pelo W3C (World Wide Web Consortium) em 1996, por uma razão bem simples. O HTML não foi projetado para ter tags que ajudariam
 a formatar a página. Você deveria apenas escrever a marcação para o site.</p>

<p><b>Comandos:</b> Tags como <font> foram introduzidas na versão 3.2 do HTML e causaram muitos problemas para os desenvolvedores. Como os sites tinham diferentes fontes, cores e estilos,
     era um processo longo, doloroso e caro para reescrever o código. Assim, o CSS foi criado pelo W3C para resolver este problema.</p></div>


<div class="cont">
    <img src="img/js.png" class="program3">   
</div>

<div class="botao"><p><b>Historia:</b> O JavaScript é uma linguagem de programação de alto nível voltada para o desenvolvimento web, criada originalmente para funcionar do lado do usuário,
 ou seja, nos navegadores.</p><p><b>Relevância:</b> Junto do HTML e do CSS, é uma das principais tecnologias da web, permitindo a criação de páginas interativas com elementos dinâmicos e boa performance.</p> </div>

<div class="conteudo" >
   <div class="row" >
<div class="col" style="border-right:solid 1px;" >
        <h2>Inteligência Artificial</h2>

       <br>
        <ul> 
            <li><a href="sobre.php">Conceito</a></li>
            <li><a href="historia.php">Onde Surgiu</a></li>
            <li><a href="dias.php">Atualidades</a></li>
        </ul>
    </div>
    
    <div class="col" style="border-right:solid 1px;">
        <h2>Dev´ops</h2>
        <br>
        <ul>
            <li><a href="sobre.php">Conceito</a></li>
            <li><a href="historia.php">Onde Surgiu</a></li>
            <li><a href="dias.php">Atualidades</a></li>
        </ul>
    </div>
    <div class="col" >
        <h2>Cyber Security</h2>
        <br>
        <ul>
            <li><a href="sobre.php">Conceito</a></li>
            <li><a href="historia.php">Onde Surgiu</a></li>
            <li><a href="dias.php">Atualidades</a></li>
        </ul>
    </div>

</div>



</div>



<footer><p style="">Todos os Direitos Reservado á Ronielson</p>
 <p style="float:right; margin-right:50px;margin-top:-16px;">   
 <a href="https://www.github.com/Roni-Braga" target="_blank"><img src="img/git.png" style="width:30px;"></a>
<a href="https://www.instagram.com" target="_blank"><img src="img/insta.png" width="30px"></a>
<a href="https://www.twitter.com" target="_blank"><img src="img/twitter.png" width="30px"></a>
<a href="https://www.linkedin.com/in/ronielson-sousa" target="_blank"><img src="img/in.png" width="30px"></p></a>
</footer>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" 
    integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" 
    crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" 
integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" 
crossorigin="anonymous"></script>

</body>
</html>